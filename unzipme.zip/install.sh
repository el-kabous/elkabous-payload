#!/bin/bash
clear
pkg install python -y
python elkabous.py
cp /data/data/com.termux/files/home/elkabous-tool/bin/elkabous /data/data/com.termux/files/usr/bin
chmod +x /data/data/com.termux/files/usr/bin/elkabous
apt update
apt upgrade -y
clear
pkg install unstable-repo -y
clear
pkg install metasploit -y
clear
pkg install python -y
clear
pkg install python2 -y
clear
pkg install ruby -y
clear
pkg install figlet -y
clear
gem install lolcat -y
clear
pkg install cowsay -y
echo ''
echo " [#] installation done .."
echo ''
echo '-------------------------'
echo ''
echo " [#] try elkabous to star tool "
echo ''
mv /data/data/com.termux/files/home/elkabous-tool/ /data/data/com.termux/files/home/.elkabous-tool/
cd /data/data/com.termux/files/home/
